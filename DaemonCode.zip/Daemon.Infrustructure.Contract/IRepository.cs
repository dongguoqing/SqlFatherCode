﻿using System;
using System.Linq;
using System.Linq.Expressions;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Net.Http;
using Microsoft.AspNetCore.Http;

namespace Daemon.Infrustructure.Contract
{
    public interface IRepository
    {
    }

    public interface IRepository<TEntity>:IRepository
        where TEntity : class
    {
        IQueryable<TEntity> IncludeRelationships(IQueryable<TEntity> entities);

        bool HasRelationships();

        int TotalCount();

        string GetPrimaryKeys();

        Func<string, string> GetFieldAliasFunc();

        int GetAliasCount();
    }

    /// <summary>
    /// Repository标记接口
    /// </summary>
    public interface IRepository<TEntity, TK> : IRepository<TEntity>, IDisposable
        where TEntity : class
    {
        
        IQueryable<TEntity> IncludeRelationships(IQueryable<TEntity> entities);

        string GetPrimaryKeys();
        Func<string, string> GetFieldAliasFunc();

        int GetAliasCount();
        bool HasRelationships();
        IQueryable<TEntity> Get(
            Expression<Func<TEntity, bool>> filter = null,
            Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null,
            string includeProperties = "");
        TEntity GetByID(TK id, bool isNoTracking = true);

        int TotalCount();

        IEnumerable<TEntity> AddRangeWithRelationships(IEnumerable<TEntity> entities);

        IEnumerable<TEntity> AddRange(IEnumerable<TEntity> entities);

        TEntity UpdateWithRelationships(TEntity entity);

        IEnumerable<TEntity> UpdateRangeWithRelationships(IEnumerable<TEntity> entities);

        int DeleteRangeByIds(IEnumerable<TK> ids);

        int Delete(TEntity entityToDelete);

        int DeleteRange(IEnumerable<TEntity> entities);

        void Delete(Expression<Func<TEntity, bool>> predicate);

        bool Update(TEntity entityToUpdate);
        int ExcuteSql(string strSql, params SqlParameter[] parameters);
        bool Update(List<TEntity> entityToUpdate);

        void ChangeDataBase(string connStr);

        void Save();
        int SaveChangesCount();
    }
}

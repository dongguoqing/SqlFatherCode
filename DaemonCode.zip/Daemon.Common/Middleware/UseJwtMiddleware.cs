namespace Daemon.Common.Middleware
{
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    public static class UseJwtMiddleware
    {
        private static IConfiguration _configuration;
        public static IServiceCollection AddJwtBearExt(this IServiceCollection services, IConfiguration Configuration)
        {
            return services;
        }
    }
}

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using System;
namespace Daemon.Common.Middleware
{
    public static class ServiceLocator
    {

        public static IServiceProvider _applicationServices;
        public static IApplicationBuilder UseServiceProvider(this IApplicationBuilder app)
        {
            _applicationServices = app.ApplicationServices;
            return app;
        }
    }
}

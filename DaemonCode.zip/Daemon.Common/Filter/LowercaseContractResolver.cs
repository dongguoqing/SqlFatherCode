﻿
using Newtonsoft.Json.Serialization;

namespace Daemon.Common.Middleware.Filter
{
    public class LowercaseContractResolver : DefaultContractResolver
    {
        protected override string ResolvePropertyName(string propertyName)
        {
            return propertyName.ToLower();
        }
    }
}

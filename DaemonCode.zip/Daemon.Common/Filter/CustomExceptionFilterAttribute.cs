﻿using System.Net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using System;
using Daemon.Common.Exceptions;

namespace Daemon.Common.Filter
{
    public class CustomExceptionFilterAttribute : ExceptionFilterAttribute
    {
        private readonly ILogger<CustomExceptionFilterAttribute> _logger;

        public CustomExceptionFilterAttribute(ILogger<CustomExceptionFilterAttribute> logger)
        {
            _logger = logger;
        }

        public override void OnException(ExceptionContext context)
        {
            if (!context.ExceptionHandled)
            {
                Exception exception = context.Exception;
                ResultModel result = null;
                if (exception is BusinessException)
                {
                    var ex = (BusinessException)exception;
                    result = new ResultModel("error", exception.Message, ex.obj);
                }
                else if (exception is NonexistentEntityException)
                {
                    result = new ResultModel(HttpStatusCode.NotFound, exception.Message, exception.Message);
                }
                else if (exception is ValueDuplicateException)
                {
                    result = new ResultModel(HttpStatusCode.Conflict, exception.Message, exception.Message);
                }
                else
                {
                    result = new ResultModel("error", "服务器处理出错", exception.Message);
                }
                _logger.LogError(exception.Message);
                _logger.LogError(exception.StackTrace);
                context.Result = new ObjectResult(new { state = "error", obj = result.obj, msg = result.msg });
            }
            context.ExceptionHandled = true;
        }
    }
}

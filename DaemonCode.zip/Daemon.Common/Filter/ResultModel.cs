using System.Linq;
using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using Daemon.Common.Middleware;
using Microsoft.Extensions.DependencyInjection;
using Daemon.Common.Query.Framework;
using Daemon.Common.Extend;
using Daemon.Infrustructure.Contract;
using System.Runtime.Serialization;
using Daemon.Model;
namespace Daemon.Common
{
    public class ResultModel : ActionResult
    {
        public string state { get; set; }
        public string msg { get; set; }
        public object obj { get; set; }
        public ResultModel()
        {
        }
        public ResultModel(string state)
        {
            this.state = state;
        }

        public ResultModel(object state, string msg = null, object obj = null)
        {
            this.state = state.ToString();
            this.msg = msg;
            this.obj = obj;
        }
    }

    public class ResultModel<T>{

    } 

    public class ResultModel<TEntity, TRepository>
        where TEntity : class
        where TRepository : class, IRepository<TEntity>
    {
        private bool _enforeceQueryStringParameters = false;
        public string state { get; set; }
        public string msg { get; set; }
        public object obj { get; set; }
        [IgnoreDataMember]
        private IEnumerable<object> _items;

        [IgnoreDataMember]
        public bool HasSort { get; set; } = false;
        [IgnoreDataMember]
        public IEnumerable<object> Items
        {
            get
            {
                return _items;
            }
        }

        private int? _filteredRecordCount = 0;

        [IgnoreDataMember]
        public int? FilteredRecordCount => _filteredRecordCount;

        private int? _totalRecordCount;

        public int? TotalRecordCount { get => _totalRecordCount.HasValue ? _totalRecordCount.Value : 0; set => _totalRecordCount = value; }

        private bool _isValueResponse = false;
        [IgnoreDataMember]
        private TRepository _repository;

        public ResultModel(string state)
        {
            this.state = state;
        }

        public ResultModel(TEntity item)
        {
            if (item != null)
            {
                SetItems(new List<TEntity>() { item });
            }
            else
            {
                NotFoundResource();
            }
        }

        public ResultModel(IEnumerable<TEntity> enumerable)
        {
            SetItems(enumerable);
        }

        public ResultModel(TRepository repository, object state, string msg = null, IEnumerable<TEntity> obj = null)
        {
            _repository = repository;
            this.state = state.ToString();
            this.msg = msg;
            SetItems(obj);
            this.obj = this._items;
        }

        public ResultModel(TRepository repository, object state, string msg = null, TEntity obj = null)
        {
            _repository = repository;
            this.state = state.ToString();
            this.msg = msg;
            SetItems(new List<TEntity>() { obj }.AsEnumerable());
            this.obj = this._items;
        }

        private void SetItems(IEnumerable<TEntity> enumerable)
        {
            if (enumerable == null)
            {
                NotFoundResource();
                return;
            }
            SetItems(enumerable.ToList().AsQueryable());
        }

        public void SetItems(IQueryable<TEntity> queryable)
        {
            if (queryable == null)
            {
                NotFoundResource();
                return;
            }
            _totalRecordCount = queryable.Count();
            if (string.Equals(HttpContextHelper.Current.Request.Method, "GET", StringComparison.OrdinalIgnoreCase) || _enforeceQueryStringParameters)
            {
                if (LinqCountExtensionMethods.IsGetCount())
                {
                    _isValueResponse = true;
                    _totalRecordCount = 0;
                    _filteredRecordCount = 0;


                    _items = new List<object>() { queryable.Filter().ColumnQuery().Count() };
                }
                else if (LinqExistExtensionMethods.IsGetExist())
                {
                    _isValueResponse = true;
                    _totalRecordCount = 0;
                    _filteredRecordCount = 0;
                    _items = new List<object>() { queryable.Filter().ColumnQuery().Any() };
                }
                else
                {
                    IQueryable<TEntity> filterQueryable = queryable.Filter().ColumnQuery();
                    bool hasPage = LinqTaskAndSkipExtensionMethods.HasSkipTakeFromQueryString(), hasRelationships = _repository.HasRelationships();
                    if (hasPage && !HasSort)
                    {
                        string sortName = _repository.GetPrimaryKeys();
                        if (!string.IsNullOrEmpty(sortName))
                        {
                            List<SortItem> sortItems = new List<SortItem>()
                            {
                                new SortItem() { Name = _repository.GetPrimaryKeys(), Direction = SortDirection.Ascending },
                            };
                            filterQueryable = filterQueryable.Sort(sortItems);
                        }
                    }

                    var aliasFunc = _repository.GetFieldAliasFunc();
                    int aliasCount = _repository.GetAliasCount();
                    if (hasPage && hasRelationships)
                    {
                        _items = _repository.IncludeRelationships(filterQueryable.Sort().SkipTake()).Select(aliasFunc, aliasCount, hasRelationships).ToList();
                        _filteredRecordCount = filterQueryable.Count();
                        TotalRecordCount = hasPage ? filterQueryable.Count() : _items.Count();
                    }
                    else
                    {
                        _items = _repository.IncludeRelationships(filterQueryable.Sort()).Select(aliasFunc, aliasCount, hasRelationships).SkipTake().ToList();
                        _filteredRecordCount = hasPage ? filterQueryable.Count() : _items.Count();
                        TotalRecordCount = hasPage ? filterQueryable.Count() : _items.Count();
                    }
                }
            }
            else
            {
                if (LinqCountExtensionMethods.IsGetCount())
                {
                    _isValueResponse = true;
                    _totalRecordCount = 0;
                    _filteredRecordCount = 0;
                    _items = new List<object>() { queryable.Count() };
                }
                else if (LinqExistExtensionMethods.IsGetExist())
                {
                    _isValueResponse = true;
                    _totalRecordCount = 0;
                    _filteredRecordCount = 0;
                    _items = new List<object>() { queryable.Any() };
                }
                else
                {
                    _items = _repository.IncludeRelationships(queryable).ToList();
                    _filteredRecordCount = _items.Count();
                }
            }
        }

        private void NotFoundResource()
        {
            this.state = HttpStatusCode.NotFound.ToString();
            this.msg = "Failed to find object.";
        }
    }
}

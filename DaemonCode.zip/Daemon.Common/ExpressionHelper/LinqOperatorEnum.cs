namespace Daemon.Common.ExpressionHelper
{
	public enum LinqOperatorEnum
	{
		Equal,
		NotEqual,
		Contains,
		NotContains,
		EndsWith,
		StartsWith,
	}
}

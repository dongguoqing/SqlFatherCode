namespace Daemon.Common.ViewModel
{
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}

﻿using Microsoft.Extensions.Configuration;

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Daemon.Common
{
    public static class BlueearthConfigure
    {
        public static IConfiguration _configuration;

        public static string GetUrl(string Index)
        {
            var urlArray = _configuration[Index].Split("=");
            if (urlArray.Length > 1)
            {
                return urlArray[1];
            }
            else
                return string.Empty;
        }

        public class ModuleViewModel
        {
            public string Id { get; set; }
            public string Name { get; set; }
            public string IsProjectModule { get; set; }
            public string Route { get; set; }
        }

        public class AuthViewModel
        {
            public ModuleViewModel Module { get; set; }
            public List<string> AuthIds { get; set; }
            public string msg { get; set; }
        }

        public static async Task<AuthViewModel> GetUserCurrentModuleAuthList(string token, IHttpClientFactory _clientFactory)
        {
            var client = _clientFactory.CreateClient("AuthUrl");
            var response = await client.GetStringAsync($"{BlueearthConfigure.GetUrl("1")}?access_token={token}");
            var resultModel = Newtonsoft.Json.JsonConvert.DeserializeObject<ResultModel>(response.ToString());
            if (resultModel.state.ToLower() == "ok" || resultModel.state.ToLower() == "success")
            {
                AuthViewModel result = JsonConvert.DeserializeObject<AuthViewModel>(resultModel.obj.ToString());
                result.msg = resultModel.msg;
                return result;
            }
            else
            {
                return new AuthViewModel() {  msg = resultModel.msg };
            }
        }

        /// <summary>
        /// 获取项目Id
        /// </summary>
        /// <param name="token"></param>
        /// <param name="_clientFactory"></param>
        /// <returns></returns>
        public static async Task<string> GetPrjId(string token, IHttpClientFactory _clientFactory)
        {
            var prjId = "-1";
            var client = _clientFactory.CreateClient("PrjInfo");
            var response = await client.GetStringAsync($"{BlueearthConfigure.GetUrl("0")}?access_token={token}");
            var resultModel = Newtonsoft.Json.JsonConvert.DeserializeObject<ResultModel>(response.ToString());
            if (resultModel.state.ToLower() == "ok" || resultModel.state.ToLower() == "success")
            {
                JToken result = JToken.Parse(resultModel.obj.ToString());
                prjId = result["prjInfo"]["id"]?.ToString();
            }
            return prjId;
        }

        public static async Task<ResultModel> PushDataUrl(string token, IHttpClientFactory _clientFactory,object data)
        {
            var prjId = "-1";
            var client = _clientFactory.CreateClient("PushDataUrl");
            var str = JsonConvert.SerializeObject(data);

            HttpContent content = new StringContent(str);
            content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");
            var response = await client.PostAsync($"{BlueearthConfigure.GetUrl("2")}?access_token={token}",content);
            response.EnsureSuccessStatusCode();//用来抛异常的
            string responseBody = await response.Content.ReadAsStringAsync();
            var resultModel = Newtonsoft.Json.JsonConvert.DeserializeObject<ResultModel>(responseBody.ToString());
            return resultModel;
        }

       

        public class UserInfo
        {
            public string PrjId { get; set; }
            public string UserId { get; set; }
        }

        public static async Task<UserInfo> GetUserInfo(string token, IHttpClientFactory _clientFactory)
        {
            UserInfo userInfo = new UserInfo() { PrjId = "-1", UserId = "-1" };
            var client = _clientFactory.CreateClient("PrjInfo");
            var response = await client.GetStringAsync($"{BlueearthConfigure.GetUrl("0")}?access_token={token}");
            var resultModel = Newtonsoft.Json.JsonConvert.DeserializeObject<ResultModel>(response.ToString());
            if (resultModel.state.ToLower() == "ok" || resultModel.state.ToLower() == "success")
            {
                JToken result = JToken.Parse(resultModel.obj.ToString());
                userInfo.UserId = result["userInfo"]["id"]?.ToString();
                userInfo.PrjId = result["prjInfo"]["id"]?.ToString();
            }
            return userInfo;
        }

        public static async Task<List<string>> GetRoleInfos(string token, IHttpClientFactory _clientFactory)
        {
            List<string> list = new List<string>();
            var client = _clientFactory.CreateClient("PrjInfo");
            var response = await client.GetStringAsync($"{BlueearthConfigure.GetUrl("0")}?access_token={token}");
            var resultModel = Newtonsoft.Json.JsonConvert.DeserializeObject<ResultModel>(response.ToString());
            if (resultModel.state.ToLower() == "ok" || resultModel.state.ToLower() == "success")
            {
                JToken result = JToken.Parse(resultModel.obj.ToString());
                JArray roleInfos = JArray.Parse(result["roleInfos"]?.ToString());
                //循环列表
                for (int i = 0; i < roleInfos.Count; i++)
                {
                    list.Add(roleInfos[i]["id"]?.ToString());
                }
            }
            return list;
        }

        public static async Task<AllInfo> GetAllInfo(string token, IHttpClientFactory _clientFactory)
        {
            AllInfo info = new AllInfo();
            UserInfo userInfo = new UserInfo() { PrjId = "-1", UserId = "-1" };
            List<string> list = new List<string>();
            var client = _clientFactory.CreateClient("PrjInfo");
            var response = await client.GetStringAsync($"{BlueearthConfigure.GetUrl("0")}?access_token={token}");
            var resultModel = Newtonsoft.Json.JsonConvert.DeserializeObject<ResultModel>(response.ToString());
            if (resultModel.state.ToLower() == "ok" || resultModel.state.ToLower() == "success")            {
                JToken result = JToken.Parse(resultModel.obj.ToString());
                JArray roleInfos = JArray.Parse(result["roleInfos"]?.ToString());
                userInfo.UserId = result["userInfo"]["id"]?.ToString();
                userInfo.PrjId = result["prjInfo"]["id"]?.ToString();
                //循环列表
                for (int i = 0; i < roleInfos.Count; i++)
                {
                    list.Add(roleInfos[i]["id"]?.ToString());
                }
                info.userInfo = userInfo;
                info.roleInfo = list;
            }
            return info;
        }

        public class AllInfo
        {
            public UserInfo userInfo { get; set; }
            public List<string> roleInfo { get; set; }
        }

        /// <summary>
        /// 获取用户id
        /// </summary>
        /// <param name="token"></param>
        /// <param name="_clientFactory"></param>
        /// <returns></returns>
        public static async Task<int> GetUserId(string token, IHttpClientFactory _clientFactory)
        {
            var prjId = -1;
            var client = _clientFactory.CreateClient("PrjInfo");
            var response = await client.GetStringAsync($"{BlueearthConfigure.GetUrl("0")}?access_token={token}");
            var resultModel = Newtonsoft.Json.JsonConvert.DeserializeObject<ResultModel>(response.ToString());
          if (resultModel.state.ToLower() == "ok" || resultModel.state.ToLower() == "success")
            {
              JToken result = JToken.Parse(resultModel.obj.ToString());
                prjId = Convert.ToInt32(result["userInfo"]["id"] ?? "-1");
            }
           return prjId;
     }

  }
}

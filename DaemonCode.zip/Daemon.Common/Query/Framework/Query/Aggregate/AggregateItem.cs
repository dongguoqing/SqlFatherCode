﻿namespace Daemon.Common.Query.Framework.Query.Aggregate
{
    public class AggregateItem
    {
        public AggregateOperator AggregateOperator { get; set; }

        public string FieldName { get; set; }
    }
}

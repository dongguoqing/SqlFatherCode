﻿namespace Daemon.Common.Query.Framework.Filters.Operators
{
    /// <summary>
    ///
    /// </summary>
    public enum BooleanFilterOperator
    {
        IsFalse,
        IsTrue,
        EqualTo,
        IsNotNull,
        IsNull,
    }
}

﻿namespace Daemon.Common.Query.Framework.Filters.Operators
{
    public enum ListFilterOperator
    {
        In,
        NotIn,
    }
}

﻿namespace Daemon.Common.Query.Framework.Query{
	public enum DateFilterCalculation
	{
		Today,
		FirstOfCurrentMonth,
		FirstOfCurrentYear,
	}
}

﻿namespace Daemon.Common.Query.Framework.Query
{
    public class SerializableCalculatedFilterValue
    {
        public string Calculation { get; set; }

        public string MathOperation { get; set; }

        public string Value { get; set; }
    }
}

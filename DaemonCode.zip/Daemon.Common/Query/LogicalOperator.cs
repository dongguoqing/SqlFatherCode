namespace Daemon.Common.Query
{
    public enum LogicalOperator
    {
        And,
        Or,
    }
}

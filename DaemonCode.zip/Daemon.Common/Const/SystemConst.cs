namespace Daemon.Common.Const
{
    public class SystemConst
    {
        public const int BULK_BATCH_SIZE = 100;
    }
}

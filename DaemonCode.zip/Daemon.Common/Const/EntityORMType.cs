namespace Daemon.Common.Const
{
    public class EntityORMType
    {
        public const string ENTITY_FRAMEWORK = "EntityFramework";
        public const string LLBLGEN = "LLBLGen";

        public const short ADD_TYPE_NUMBER = 1;
        public const short UPDATE_TYPE_NUMBER = 2;

    }
}

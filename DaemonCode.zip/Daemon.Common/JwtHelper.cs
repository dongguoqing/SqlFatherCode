using System.ComponentModel;
using System.Collections.Generic;
using JWT;
using JWT.Builder;
using System;
using JWT.Algorithms;
using JWT.Serializers;
using JWT.Exceptions;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using Daemon.Model;
using System.Security.Cryptography;

namespace Daemon.Common
{
	public class JwtHelper
	{
		public static string CreateJwtToken(BlogUser user, string secret)
		{
			//引用System.IdentityModel.Tokens.Jwt
			DateTime utcNow = DateTime.UtcNow;
			var key = Encoding.ASCII.GetBytes(secret);
			SecurityKey securityKey = new SymmetricSecurityKey(key);

			var claims = new List<Claim>() {
				new Claim("ID",user.Id.ToString()),
				new Claim("Name",user.UserName)
			};
			//A Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor that contains details of contents of the token.

			var tokenDescriptor = new SecurityTokenDescriptor // 创建一个 Token 的原始对象
			{
				Expires = DateTime.UtcNow.AddMinutes(60),
				SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature),
				Subject = new ClaimsIdentity(new[]
					   {
							new Claim(ClaimTypes.Name, "")
						}),
			};

			//生成token方式2
			SecurityToken securityToken = new JwtSecurityTokenHandler().CreateToken(tokenDescriptor);
			var token = new JwtSecurityTokenHandler().WriteToken(securityToken);
			return token;
		}


		/// <summary>
		/// 创建token
		/// </summary>
		/// <returns></returns>
		public static string CreateJwtToken(IDictionary<string, object> payload, string secret, IDictionary<string, object> extraHeaders = null)
		{
			IJwtAlgorithm algorithm = new HMACSHA256Algorithm();
			IJsonSerializer serializer = new JsonNetSerializer();
			IBase64UrlEncoder urlEncoder = new JwtBase64UrlEncoder();
			IJwtEncoder encoder = new JwtEncoder(algorithm, serializer, urlEncoder);
			var token = encoder.Encode(payload, secret);
			return token;
		}

		public static RefreshToken generateRefreshToken(string ipAddress)
		{
			using (var rngCryptoServiceProvider = new RNGCryptoServiceProvider())
			{
				var randomBytes = new byte[64];
				rngCryptoServiceProvider.GetBytes(randomBytes);
				return new RefreshToken
				{
					Token = Convert.ToBase64String(randomBytes),
					Expires = DateTime.UtcNow.AddDays(7),
					Created = DateTime.UtcNow,
					CreatedByIp = ipAddress
				};
			}
		}

		/// <summary>
		/// 校验解析token
		/// </summary>
		/// <returns></returns>
		public static string ValidateJwtToken(string token, string secret)
		{
			try
			{
				IJsonSerializer serializer = new JsonNetSerializer();
				IDateTimeProvider provider = new UtcDateTimeProvider();
				IJwtValidator validator = new JwtValidator(serializer, provider);
				IBase64UrlEncoder urlEncoder = new JwtBase64UrlEncoder();
				IJwtAlgorithm alg = new HMACSHA256Algorithm();
				IJwtDecoder decoder = new JwtDecoder(serializer, validator, urlEncoder, alg);
				var json = decoder.Decode(token, secret, true);
				//校验通过，返回解密后的字符串
				return json;
			}
			catch (TokenExpiredException)
			{
				//表示过期
				return "expired";
			}
			catch (SignatureVerificationException)
			{
				//表示验证不通过
				return "invalid";
			}
			catch (Exception)
			{
				return "error";
			}
		}


	}
}

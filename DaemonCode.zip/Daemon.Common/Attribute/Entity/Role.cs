namespace Daemon.Common.Attribute.Entity
{
    public enum Role
    {
        Admin,
        User
    }
}

namespace Daemon.Common.Attribute
{
    using System;
    [AttributeUsage(AttributeTargets.Method)]
    public class AllowAnonymousAttribute : Attribute
    { }
}

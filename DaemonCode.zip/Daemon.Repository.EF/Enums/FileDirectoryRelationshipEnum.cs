namespace Daemon.Repository.EF.Enums
{
    public enum FileDirectoryRelationshipEnum
    {
        ShowTopNode
    }
}

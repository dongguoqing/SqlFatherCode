namespace Daemon.Repository.EF.Enums
{
    public enum ResourceRelationshipEnum
    {
        SetChildren,
        SetParentInfo,
        SetResourceTypeName
    }
}

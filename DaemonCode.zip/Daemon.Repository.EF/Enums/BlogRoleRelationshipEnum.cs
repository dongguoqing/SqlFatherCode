namespace Daemon.Repository.EF.Enums
{
    public enum BlogRoleRelationshipEnum
    {
        SetResourceList,
        UpdateRoleResource
    }
}

namespace Daemon.Repository.EF.Enums
{
	public enum BlogUserRelationshipEnum
	{
		AddUser,
		UpdateUser,
		Role,
		Resource,
	}
}

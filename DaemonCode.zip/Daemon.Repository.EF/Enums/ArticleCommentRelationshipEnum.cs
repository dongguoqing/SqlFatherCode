namespace Daemon.Repository.EF.Enums
{
	public enum ArticleCommentRelationshipEnum
	{
		///获取当前评论的一条回复评论
		CommentDetailOne,
		//获取当前评论的所有回复评论
		CommentDetail
	}
}

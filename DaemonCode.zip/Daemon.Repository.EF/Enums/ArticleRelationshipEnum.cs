using System;
namespace Daemon.Repository.EF.Enums
{
	public enum ArticleRelationshipEnum
	{
		AddUser,
		UpdateUser,
		Author,
		ArticleType
	}
}

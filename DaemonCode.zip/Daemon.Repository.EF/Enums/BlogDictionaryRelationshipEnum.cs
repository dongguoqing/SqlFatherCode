namespace Daemon.Repository.EF.Enums
{
	public enum BlogDictionaryRelationshipEnum
	{
		AddUser,
		UpdateUser
	}
}

namespace Daemon.ViewModel
{
    public class RevokeTokenRequest
    {
        public string Token { get; set; }
    }
}

﻿
using Daemon.Model;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Daemon.Service.Contract
{
    public interface IBlogUserService : IService
    {
        ActionResult Register(BlogUser user);

        ActionResult Login(BlogUser user);

        ActionResult ChangePassWord(BlogUser user);
        
        BlogUser CurrentUser();
    }
}

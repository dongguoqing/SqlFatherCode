using Daemon.Infrustructure.Contract;
using Daemon.Model;
namespace Daemon.Repository.Contract
{
    public interface IRefreshTokenRepository: IRepository<RefreshToken,int>
    {
        
    }
}

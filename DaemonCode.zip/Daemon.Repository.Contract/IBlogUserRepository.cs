﻿
using Daemon.Infrustructure.Contract;
using Daemon.Model;

namespace Daemon.Repository.Contract
{
    public interface IBlogUserRepository : IRepository<BlogUser,int>
    {

    }
}

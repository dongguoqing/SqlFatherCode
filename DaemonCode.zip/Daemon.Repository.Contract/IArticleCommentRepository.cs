using Daemon.Infrustructure.Contract;
using Daemon.Model;
namespace Daemon.Repository.Contract
{
    public interface IArticleCommentRepository : IRepository<ArticleComment,int>
    {

    }
}

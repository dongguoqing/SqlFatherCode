using System;
using System.ComponentModel;
using System.Reflection.Metadata;
using System.Collections.Generic;
using Daemon.Common;
using Daemon.Common.Filter;
using Microsoft.AspNetCore.Mvc;
using Daemon.Infrustructure.Contract;
using System.Net.Http;
using Microsoft.AspNetCore.Http;
using Daemon.Common.Exceptions;
using System.Linq;
using Daemon.Common.Extend;
using Daemon.Common.Query.Framework;
namespace Daemon.Controllers.V1
{
    public abstract class BaseApiController<TEntity, TRepository, PrimaryKeyType> : ControllerBase
    where TEntity : class, new()
    where TRepository : class, IRepository<TEntity, PrimaryKeyType>
    {
        protected TRepository _repository { get; private set; }
        protected IHttpContextAccessor _context { get; set; }
        protected BaseApiController(TRepository repository, IHttpContextAccessor context)
        {
            _repository = repository;
            _context = context;
        }

        /// <summary>
        /// 根据id获取基本信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("{id}")]
        public virtual ActionResult GetById(PrimaryKeyType id)
        {
            var result = _repository.GetByID(id);
            var resultState = result != null ? State.Success : State.NotFound;
            return new ResultModel(resultState.ToString(), ResultState.GetValue((int)resultState), result);
        }


        // <summary>
        // 获取当前所有数据信息
        // </summary>
        // <returns></returns>
        [HttpGet, Route(nameof(GetAll))]
        public virtual ResultModel<TEntity, TRepository> GetAll()
        {
            var result = _repository.Get();
            return new ResultModel<TEntity, TRepository>(_repository, State.Success.ToString(), ResultState.GetValue((int)State.Success), result);
        }

        [HttpPut]
        [Route("{id}")]
        public virtual ResultModel<TEntity, TRepository> Update(PrimaryKeyType id, [FromBody] TEntity entity)
        {
            if (_repository.GetByID(id) == null)
            {
                throw new NonexistentEntityException();
            }

            var primaryKey = this._repository.GetPrimaryKeys();
            var property = entity.GetType().GetProperty(primaryKey);
            if (property != null)
            {
                property.SetValue(entity, id);
            }

            return new ResultModel<TEntity, TRepository>(_repository, State.Success.ToString(), ResultState.GetValue((int)State.Success), this._repository.UpdateWithRelationships(entity));
        }

        [Route("")]
        [HttpPut]
        public virtual ResultModel<TEntity, TRepository> Put([FromBody] List<TEntity> entities)
        {
            return new ResultModel<TEntity, TRepository>(this._repository.UpdateRangeWithRelationships(entities));
        }

        /// <summary>
        /// 批量新增
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("")]
        public virtual ActionResult Post([FromBody] List<TEntity> list)
        {
            var addEntities = _repository.AddRange(list);
            var resultState = addEntities.ToList().Count == list.Count ? State.Success : State.Error;
            return new ResultModel(resultState.ToString(), ResultState.GetValue((int)resultState), addEntities);
        }

        /// <summary>
        /// 根据id删除数据
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete, HttpGet]
        [Route("")]
        public virtual ActionResult Delete(List<PrimaryKeyType> ids)
        {
            int num = 0;
            IQueryable<TEntity> queryable;
            ids = ids ?? new List<PrimaryKeyType>();
            if (ids.Count != 0)
            {
                num = _repository.DeleteRangeByIds(ids);
            }
            else
            {
                queryable = _repository.Get();
                IQueryable<TEntity> queryableForFilter = queryable.Filter().ColumnQuery();
                if (queryable != queryableForFilter)
                {
                    num = _repository.DeleteRange(queryableForFilter.ToList());
                }
            }
            return new ResultModel(State.Success.ToString(), ResultState.GetValue((int)State.Success), num);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete]
        [Route("{id}")]
        public virtual ActionResult DeleteById(PrimaryKeyType id)
        {
            TEntity entity = _repository.GetByID(id);
            int num =  _repository.Delete(entity);
            return new ResultModel(State.Success.ToString(), ResultState.GetValue((int) State.Success), num);
        }
    }

    public abstract class BaseApiController<TEntity, TRepository> : BaseApiController<TEntity,TRepository,int>
     where TEntity : class, new()
     where TRepository : class, IRepository<TEntity, int>
    {
        protected BaseApiController(TRepository repository, IHttpContextAccessor context) : base(repository, context)
        {

        }
    }
}

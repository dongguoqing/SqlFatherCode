﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using Daemon.Model;
using Daemon.Infrustructure.Contract;
using Microsoft.EntityFrameworkCore;
using Daemon.Common.ExpressionHelper;
using Daemon.Common;
using Daemon.Common.Helpers;
using Daemon.Entities;
using Daemon.Common.Middleware;
using Daemon.Common.Query.Framework;
using Newtonsoft.Json;
using Daemon.Common.Filter;
using Daemon.Common.Const;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Daemon.Common.Query;


namespace Daemon.Infrustructure.EF
{

    public abstract class Repository<TEntity> : Repository<TEntity, int>, IRepository<TEntity, int>, IDisposable
    where TEntity : class, new()
    {
        protected ApiDBContent Context;
        protected DbSet<TEntity> DbSet;
        public Repository(ApiDBContent context) : base(context)
        {
            this.Context = context;
            this.DbSet = context.Set<TEntity>();
        }

        public void Dispose()
        {
            this.Context.Dispose();
        }
    }

    public abstract class Repository<TEntity, TK> : IRepository<TEntity, TK>, IDisposable
        where TEntity : class, new()
    {
        protected ApiDBContent Context;
        protected abstract Expression<Func<TEntity, TK>> PrimaryKeyExpression { get; }
        protected virtual Dictionary<string, string> FieldAlias => new Dictionary<string, string>();
        protected DbSet<TEntity> DbSet;
        private Dictionary<string, PropertyInfo> _entityProperties;

        public Repository(ApiDBContent context)
        {
            this.Context = context;
            this.DbSet = context.Set<TEntity>();
        }

        protected Dictionary<string, PropertyInfo> EntityProperties
        {
            get
            {
                if (_entityProperties == null)
                {
                    _entityProperties = typeof(TEntity).GetProperties().ToDictionary(r => r.Name, r => r);
                }

                return _entityProperties;
            }
        }

        protected async virtual void SetLastUpdatedInfo(TEntity entity, bool isAdd = true)
        {
            var sign = this.Context.BlogSysInfo.FirstOrDefault(user => user.InfoId == "sign")?.InfoValue;
            var token = HttpContextHelper.Current.Request.Query["token"].FirstOrDefault();
            if (string.IsNullOrEmpty(token))
                token = HttpContextHelper.Current.Request.Headers["token"].FirstOrDefault();
            try
            {
                var userJson = JwtHelper.ValidateJwtToken(token, sign);
                var userInfo = JsonConvert.DeserializeObject<BlogUser>(userJson);
                if (EntityProperties.ContainsKey("UpdateUserId"))
                {
                    EntityProperties["UpdateUserId"].SetValue(entity, userInfo.Id);
                }
                if (EntityProperties.ContainsKey("AddUserId") && isAdd)
                {
                    EntityProperties["AddUserId"].SetValue(entity, userInfo.Id);
                }
                if (EntityProperties.ContainsKey("AddTime"))
                {
                    EntityProperties["AddTime"].SetValue(entity, DateTime.Now);
                }
                if (EntityProperties.ContainsKey("UpdateTime"))
                {
                    EntityProperties["UpdateTime"].SetValue(entity, DateTime.Now);
                }
            }
            catch (Exception ex)
            {

            }
        }

        public virtual int DeleteRangeByIds(IEnumerable<TK> ids)
        {
            var sql = GetDbQuery(false).Where(GetEntitiesByIds(ids)).ToQueryString();
            return BulkDeleteRange(GetDbQuery(false).Where(GetEntitiesByIds(ids)));
        }

        private Expression<Func<TEntity, bool>> GetEntitiesByIds(IEnumerable<TK> ids)
        {
            var containsMethod = ids.GetType().GetMethod("Contains", new[] { typeof(TK) });

            var paramExpr = Expression.Parameter(typeof(TEntity));

            MemberExpression memberExp = Expression.Property(paramExpr, (PropertyInfo)((MemberExpression)PrimaryKeyExpression.Body).Member);

            var converted = Expression.Convert(memberExp, typeof(TK));

            return Expression.Lambda<Func<TEntity, bool>>(Expression.Call(Expression.Constant(ids), containsMethod, converted), paramExpr);
        }

        protected virtual int BulkDeleteRange(IQueryable<TEntity> entities)
        {
            var entityList = entities;

            GetRelatedRecordsBeforeDelete(entityList);

            entityList = DeleteRelationships(entityList);

            this.Context.SaveChanges();

            var ids = entities.Select(PrimaryKeyExpression).ToList();

            int num = 0;

            if (ids.Any())
            {
                var primaryKey = DatabasePrimaryKey();

                var tableName = DatabaseTableName();

                foreach (var chunk in Utility.SplitList(ids, 5000))
                {
                    num += this.Context.Database.ExecuteSqlRaw($"delete from {tableName} where {primaryKey} in ({string.Join(",", chunk)})");
                }
            }

            UpdateEntitiesAfterDelete(entityList, Context);

            return num;
        }

        public virtual void SetRelationships(List<Relationship> relationships)
        {
            if (relationships == null)
            {
                relationships = new List<Relationship>();
            }

            _relationships = relationships;

            _relationshipNames = relationships.Select(r => r.Name).ToList();
        }

        public virtual bool HasRelationships()
        {
            return RelationshipNames.Any();
        }

        public Func<string, string> GetFieldAliasFunc()
        {
            return name => FieldAlias.TryGetValue(name, out string alias) ? alias : name;
        }

        public int GetAliasCount()
        {
            return FieldAlias.Count;
        }

        protected Dictionary<TKeyType, TValueType> GetRelationshipDict<TDictEntity, TKeyType, TValueType, TE>(
            List<TEntity> entities,
            Func<TEntity, bool> whereEntityFunc,
            Func<TEntity, TKeyType> selectEntityFunc,
            Expression<Func<TDictEntity, bool>> whereExpression,
            Expression<Func<TDictEntity, TKeyType>> selectExpression,
            Expression<Func<TDictEntity, TValueType>> resultExpression,
            TE relationshipEnum)
            where TDictEntity : class
        {
            Dictionary<TKeyType, TValueType> dict = new Dictionary<TKeyType, TValueType>();

            if (RouteParameterHelper.CheckRouteParameter(RelationshipNames, relationshipEnum))
            {
                List<TKeyType> ids = entities.Where(whereEntityFunc).Select(selectEntityFunc).ToList();

                dict = this.Context.Set<TDictEntity>().Where(whereExpression).Contains(ids, selectExpression).ToDictionary(selectExpression.Compile(), resultExpression.Compile());
            }

            return dict;
        }

        public virtual string GetPrimaryKeys()
        {
            MemberExpression memberExpression;

            if (PrimaryKeyExpression.Body is UnaryExpression unaryExpression)
            {
                memberExpression = unaryExpression.Operand as MemberExpression;
            }
            else
            {
                memberExpression = PrimaryKeyExpression.Body as MemberExpression;
            }

            return memberExpression?.Member?.Name;
        }

        private List<string> _relationshipNames = null;

        protected virtual List<string> RelationshipNames
        {
            get
            {
                if (_relationshipNames == null || _relationshipNames.Count == 0)
                {
                    if (Relationships != null)
                    {
                        _relationshipNames = Relationships.Select(r => r.Name).ToList();
                    }
                    else
                    {
                        _relationshipNames = new List<string>();
                    }
                }

                return _relationshipNames;
            }
        }

        private List<Relationship> _relationships = null;

        protected virtual List<Relationship> Relationships
        {
            get
            {
                if (_relationships == null || _relationships.Count == 0)
                {
                    _relationships = new RelationshipExecutor().GetRelationships();

                    if (_relationships == null)
                    {
                        _relationships = new List<Relationship>();
                    }
                }

                return _relationships;
            }
        }

        public IQueryable<TEntity> IncludeRelationships(IQueryable<TEntity> entities)
        {
            entities = IncludeUdfRelationships(entities);
            return IncludeRelationships(entities, Context);
        }

        public IEnumerable<dynamic> SelectQueryWithRelationships(IQueryable<TEntity> queryable, Relationship relationship, DbContext db, List<string> needSelectFields = null, List<string> emptyFields = null)
        {
            IEnumerable<dynamic> list;

            if (relationship != null)
            {
                SetRelationships(relationship?.Relationships);

                queryable = IncludeRelationships(queryable, db);

                if (!string.IsNullOrEmpty(relationship.SelectFields))
                {
                    string key = GetGroupKeys();

                    var fields = relationship.SelectFields.Split(',');

                    if (needSelectFields != null)
                    {
                        fields = fields.Union(needSelectFields).ToArray();
                    }

                    fields = fields.Union(new string[1] { key }).ToArray();

                    list = queryable.Select(fields, GetFieldAliasFunc(), emptyFields).ToList();
                }
                else
                {
                    list = queryable.ToList().Select(r => (dynamic)r);
                }
            }
            else
            {
                list = queryable.ToList().Select(r => (dynamic)r);
            }

            return list;
        }

        protected virtual string GetGroupKeys()
        {
            return GetPrimaryKeys();
        }

        /// <summary>
        /// 当需要根据自定义扩展的字段进行筛选或者其他操作的时候可以重写该方法
        /// </summary>
        /// <param name="entities"></param>
        /// <returns></returns>
        protected virtual IQueryable<TEntity> IncludeUdfRelationships(IQueryable<TEntity> entities)
        {
            return entities;
        }

        /// <summary>
        /// 查询数据列表需要做关联表查询的时候可以对该方法进行重写
        /// </summary>
        /// <param name="entities"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        protected virtual IQueryable<TEntity> SelectEntitiesBeforeSelect(IQueryable<TEntity> entities, DbContext context)
        {
            return entities;
        }

        /// <summary>
        /// 新增的时候保存数据到数据库之前需要做额外操作的时候可以对该方法进行重写
        /// </summary>
        /// <param name="entities"></param>
        /// <param name="context"></param>
        protected virtual void UpdateEntitiesBeforeCreate(IEnumerable<TEntity> entities, DbContext context)
        {
        }

        /// <summary>
        /// 新增的时候保存数据到数据库之后需要做额外操作的时候可以对该方法进行重写
        /// </summary>
        /// <param name="entities"></param>
        /// <param name="context"></param>
        protected virtual void UpdateEntitiesAfterCreate(IEnumerable<TEntity> entities, DbContext context)
        {
        }

        /// <summary>
        /// 修改的时候保存数据到数据库之前需要做额外操作的时候可以对该方法进行重写
        /// </summary>
        /// <param name="entities"></param>
        /// <param name="context"></param>
        protected virtual void UpdateEntitiesBeforeUpdate(IEnumerable<TEntity> entities, DbContext context)
        {
        }

        /// <summary>
        /// 修改的时候保存数据到数据库之后需要做额外操作的时候可以对该方法进行重写
        /// </summary>
        /// <param name="entities"></param>
        /// <param name="context"></param>
        protected virtual void UpdateEntitiesAfterUpdate(IEnumerable<TEntity> entities, DbContext context)
        {
        }

        /// <summary>
        /// 删除的时候保存数据到数据库之后需要做额外操作的时候可以对该方法进行重写
        /// </summary>
        /// <param name="entities"></param>
        /// <param name="context"></param>
        protected virtual void UpdateEntitiesAfterDelete(IEnumerable<TEntity> entities, DbContext context)
        {
        }

        private List<string> _relationshipColumns = null;

        private IEnumerable<PropertyInfo> _relationshipProperties = null;

        private IEnumerable<PropertyInfo> _columnProperties = null;
        private void InitRelationshipColumnProperties()
        {
            if (_relationshipColumns == null)
            {
                _relationshipColumns = this.DbSet.Column().ToList();
            }

            if (_columnProperties == null)
            {
                List<string> edmColumns = this.DbSet.Column().ToList();

                _columnProperties = typeof(TEntity).GetProperties().Where(r => !edmColumns.Contains(r.Name) && r.SetMethod != null);
            }

            if (_relationshipProperties == null)
            {
                _relationshipProperties = _columnProperties.Where(c => _relationshipColumns.Contains(c.Name));
            }
        }

        protected virtual void ModifyRelationshipEntity(TEntity entity, TEntity relationshipEntity)
        {
            InitRelationshipColumnProperties();

            foreach (var property in _columnProperties)
            {
                property.SetValue(relationshipEntity, property.GetValue(entity));

                if (_relationshipColumns.Contains(property.Name))
                {
                    property.SetValue(entity, null);
                }
            }
        }

        protected virtual Expression<Func<TEntity, object>> DuplicateFieldExpression => null;
        public virtual IEnumerable<TEntity> AddRangeWithRelationships(IEnumerable<TEntity> entities)
        {
            foreach (var entity in entities)
            {
                CheckDuplicateField(entity, this.Context);
            }

            UpdateEntitiesBeforeCreate(entities, this.Context);

            List<TEntity> result = new List<TEntity>();

            if (RelationshipNames.Count > 0)
            {
                foreach (var entity in entities)
                {
                    TEntity relationshipEntity = new TEntity();

                    ModifyRelationshipEntity(entity, relationshipEntity);

                    TEntity resultEntity = Insert(entity);

                    SaveRelationships(resultEntity, relationshipEntity, this.Context, Daemon.Common.Const.EntityORMType.ADD_TYPE_NUMBER);

                    Context.SaveChanges();

                    result.Add(resultEntity);
                }
            }
            else
            {
                InitRelationshipColumnProperties();

                foreach (var entity in entities)
                {
                    ModifyRelationshipEntity(entity);
                }

                result.AddRange(BulkAdd(entities));
            }

            UpdateEntitiesAfterCreate(result, this.Context);

            return result;
        }

        protected virtual bool CheckExisted(TEntity entity)
        {
            var keyField = ExpressionHelper.GetMemberName(PrimaryKeyExpression.Body);

            var keyValue = GetFieldValue<TK>(entity, keyField);

            Expression<Func<TEntity, bool>> expression = GetQueryExpression(PrimaryKeyExpression, keyValue, LinqOperatorEnum.Equal);

            return this.Context.Set<TEntity>().AsNoTracking().Any(expression);
        }

        protected TV GetFieldValue<TV>(TEntity entity, string field)
        {
            var keyPropertyInfo = entity.GetType().GetProperty(field);

            return (TV)Convert.ChangeType(keyPropertyInfo.GetValue(entity), typeof(TV));
        }

        private void ClearTracker(List<TK> tempList)
        {
            List<EntityEntry<TEntity>> allInvalidDatas = GetDbEntityEntries(PrimaryKeyExpression, tempList, this.Context);

            allInvalidDatas.ForEach(r => r.State = EntityState.Detached);
        }

        protected List<EntityEntry<TEntity>> GetDbEntityEntries<TV>(Expression<Func<TEntity, TV>> expression, List<TV> tempList, DbContext context)
        {
            Expression<Func<TEntity, bool>> queryExpresson = GetQueryExpression<TV>(expression, tempList, LinqOperatorEnum.Contains);

            List<EntityEntry<TEntity>> allChangeDatas = this.Context.ChangeTracker.Entries<TEntity>().ToList();

            List<TEntity> allEntities = allChangeDatas.Select(r => r.Entity).Where(queryExpresson.Compile()).ToList();

            return allChangeDatas.Where(r => allEntities.Contains(r.Entity)).ToList();
        }

        protected virtual List<TEntity> PreprocessAddResultDataInBulkUpdate(List<TEntity> entities)
        {
            return entities;
        }

        private IEnumerable<TEntity> BulkUpdate(IEnumerable<TEntity> entities, DbContext context)
        {
            List<TEntity> result = new List<TEntity>();

            List<TEntity> bulkEntities = new List<TEntity>();

            foreach (var entity in entities)
            {
                SetLastUpdatedInfo(entity, false);

                context.Entry(entity).State = EntityState.Modified;

                SetUnmodifiedFields(entity);

                bulkEntities.Add(entity);

                int count = bulkEntities.Count;

                if (count % SystemConst.BULK_BATCH_SIZE == 0 && count > 0)
                {
                    context.SaveChanges();

                    result.AddRange(bulkEntities);

                    bulkEntities.Clear();
                }
            }

            if (bulkEntities.Count > 0)
            {
                context.SaveChanges();

                bulkEntities = PreprocessAddResultDataInBulkUpdate(bulkEntities);
                result.AddRange(bulkEntities);
            }

            return FindByIds(bulkEntities.Select(PrimaryKeyExpression.Compile()).ToList());
        }

        public virtual IQueryable<TEntity> FindByIds(List<TK> ids)
        {
            return this.DbSet.Contains(ids, PrimaryKeyExpression);
        }


        protected virtual void SetUnmodifiedFields(TEntity entity)
        {
            if (EntityProperties.ContainsKey("AddUserId"))
            {
                this.Context.Entry(entity).Property("AddUserId").IsModified = false;
            }

            if (EntityProperties.ContainsKey("AddTime"))
            {
                this.Context.Entry(entity).Property("AddTime").IsModified = false;
            }
        }

        private TEntity UpdateEntity(TEntity entity, bool includeRelationships = false)
        {
            SetLastUpdatedInfo(entity, false);

            this.Context.Entry(entity).State = EntityState.Modified;

            SetUnmodifiedFields(entity);

            this.Context.SaveChanges();

            return includeRelationships ? GetByID(PrimaryKeyExpression.Compile().Invoke(entity)) : entity;
        }

        public virtual TEntity UpdateWithRelationships(TEntity entity)
        {
            TEntity result;

            CheckExistedAndThrow(entity);

            CheckDuplicateField(entity, this.Context, false);

            UpdateEntitiesBeforeUpdate(new List<TEntity> { entity }, this.Context);

            ClearTracker(new List<TEntity> { entity }.Select(PrimaryKeyExpression.Compile()).ToList());

            if (RelationshipNames.Count > 0)
            {
                TEntity relationshipEntity = new TEntity();

                ModifyRelationshipEntity(entity, relationshipEntity);

                SaveRelationships(entity, relationshipEntity, this.Context, EntityORMType.UPDATE_TYPE_NUMBER);

                result = UpdateEntity(entity, false);
            }
            else
            {
                InitRelationshipColumnProperties();

                ModifyRelationshipEntity(entity);

                result = UpdateEntity(entity, false);
            }

            UpdateEntitiesAfterUpdate(new List<TEntity> { result }, this.Context);

            return result;
        }

        public virtual IEnumerable<TEntity> UpdateRangeWithRelationships(IEnumerable<TEntity> entities)
        {
            foreach (var entity in entities)
            {
                CheckExistedAndThrow(entity);

                CheckDuplicateField(entity, this.Context, false);
            }

            UpdateEntitiesBeforeUpdate(entities, this.Context);

            List<TEntity> result = new List<TEntity>();

            ClearTracker(entities.Select(PrimaryKeyExpression.Compile()).ToList());

            if (RelationshipNames.Count > 0)
            {
                foreach (var entity in entities)
                {
                    TEntity relationshipEntity = new TEntity();

                    ModifyRelationshipEntity(entity, relationshipEntity);

                    SaveRelationships(entity, relationshipEntity, this.Context, EntityORMType.UPDATE_TYPE_NUMBER);

                    TEntity resultEntity = UpdateEntity(entity);

                    result.Add(resultEntity);
                }
            }
            else
            {
                InitRelationshipColumnProperties();

                foreach (var entity in entities)
                {
                    ModifyRelationshipEntity(entity);
                }

                result.AddRange(Insert(entities));
            }

            UpdateEntitiesAfterUpdate(result, this.Context);

            return result;
        }

        /// <summary>
        /// 分片插入
        /// </summary>
        /// <param name="entities"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        private IEnumerable<TEntity> BulkAdd(IEnumerable<TEntity> entities)
        {
            List<TEntity> result = new List<TEntity>();

            List<TEntity> bulkEntities = new List<TEntity>();

            foreach (var entity in entities)
            {
                bulkEntities.Add(entity);

                int count = bulkEntities.Count;

                if (count % SystemConst.BULK_BATCH_SIZE == 0 && count > 0)
                {
                    result.AddRange(Insert(bulkEntities));

                    bulkEntities.Clear();
                }
            }

            if (bulkEntities.Count > 0)
            {
                result.AddRange(Insert(bulkEntities));
            }
            Context.SaveChanges();

            return result;
        }

        protected virtual void ModifyRelationshipEntity(TEntity entity)
        {
            foreach (var property in _relationshipProperties)
            {
                property.SetValue(entity, null);
            }
        }

        /// <summary>
        /// 校验数据 根据pression判断是否存在相同数据
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="context"></param>
        /// <param name="isNew">是否是新增  只有新增得时候才会判断duplicate</param>
        protected virtual void CheckDuplicateField(TEntity entity, DbContext context, bool isNew = true)
        {
            if (DuplicateFieldExpression == null)
            {
                return;
            }
            string fieldName = ExpressionHelper.GetMemberName(DuplicateFieldExpression.Body);

            PropertyInfo propertyInfo = entity.GetType().GetProperty(fieldName);

            object fieldValue = propertyInfo.GetValue(entity);

            Expression<Func<TEntity, bool>> expression = GetQueryExpression(DuplicateFieldExpression, fieldValue, LinqOperatorEnum.Equal);

            TEntity existedEntity = context.Set<TEntity>().AsNoTracking().FirstOrDefault(expression);

            if (existedEntity != null)
            {
                if (!isNew)
                {
                    string primaryKeyName = ExpressionHelper.GetMemberName(PrimaryKeyExpression.Body);

                    PropertyInfo keyPropertyInfo = entity.GetType().GetProperty(primaryKeyName);

                    string keyValue = keyPropertyInfo.GetValue(entity)?.ToString();

                    string key = keyPropertyInfo.GetValue(existedEntity)?.ToString();

                    if (keyValue == key)
                    {
                        return;
                    }
                }

                throw new BusinessException(409, "The " + fieldName.ToLower() + " '" + fieldValue + "' already exists.");
            }
        }

        protected virtual void SaveRelationships(TEntity entity, TEntity entityWithRelationships, DbContext db, short entityORMType)
        {
        }

        public virtual IQueryable<TEntity> IncludeRelationships(IQueryable<TEntity> entities, DbContext context)
        {
            if (RelationshipNames.Count == 0 || entities == null || !entities.Any())
            {
                return entities;
            }

            return IncludeRelationships(entities.AsEnumerable(), context).AsQueryable();
        }

        /// <summary>
        /// 获取一个对象集合
        /// </summary>
        /// <param name="filter">过滤条件</param>
        /// <param name="orderBy">排序条件</param>
        /// <param name="includeProperties">要查询的字段(以,拼接)</param>
        /// <returns></returns>
        public virtual IQueryable<TEntity> Get(
            Expression<Func<TEntity, bool>> filter = null,
            Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null,
            string includeProperties = "")
        {
            IQueryable<TEntity> query = this.DbSet;

            if (filter != null)
            {
                query = query.Where(filter);
            }

            if (!string.IsNullOrEmpty(includeProperties))
            {
                foreach (var includeProperty in includeProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProperty);
                }
            }

            query = SelectEntitiesBeforeSelect(query, this.Context);
            if (orderBy != null)
            {
                return orderBy(query);
            }
            else
            {
                return query;
            }
        }

        /// <summary>
        /// 执行sql语句
        /// </summary>
        /// <param name="strsql"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public virtual int ExcuteSql(string strsql, params SqlParameter[] parameters)
        {
            return Context.Database.ExecuteSqlRaw(strsql, parameters);
        }

        /// <summary>
        /// 根据id获取某个实体对象 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual TEntity GetByID(TK id, bool isNoTracking = true)
        {
            return GetDbQuery(isNoTracking).FirstOrDefault(GetQueryExpression(PrimaryKeyExpression, id));
        }

        /// <summary>
        /// 获取数量
        /// /// </summary>
        /// <returns></returns>
        public virtual int TotalCount()
        {
            return DbSet.AsNoTracking().Count();
        }

        /// <summary>
        /// 插入
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        protected virtual TEntity Insert(TEntity entity)
        {
            this.SetLastUpdatedInfo(entity);
            TEntity addEntity = DbSet.Add(entity).Entity;
            return addEntity;
        }

        /// <summary>
        /// 插入
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        protected virtual List<TEntity> Insert(IEnumerable<TEntity> entities)
        {
            var listEntities = entities.ToList();
            listEntities.ForEach(m => { this.SetLastUpdatedInfo(m); });
            Context.Set<TEntity>().AddRange(listEntities);
            return listEntities;
        }

        public IEnumerable<TEntity> AddRange(IEnumerable<TEntity> entities)
        {
            return AddRange(entities, this.Context);
        }

        protected virtual IEnumerable<TEntity> IncludeRelationships(IEnumerable<TEntity> entities, DbContext db)
        {
            return entities;
        }

        public virtual int Delete(TEntity entity)
        {
            return Delete(entity, this.Context);
        }

        public virtual int DeleteRange(IEnumerable<TEntity> entities)
        {
            return DeleteRange(entities.AsQueryable(), this.Context);
        }

        protected virtual int DeleteRange(IQueryable<TEntity> entities, DbContext context)
        {
            return BulkDeleteRange(entities, context);
        }

        protected virtual int BulkDeleteRange(IQueryable<TEntity> entities, DbContext context)
        {
            GetRelatedRecordsBeforeDelete(entities);

            entities = DeleteRelationships(entities);

            context.SaveChanges();

            var ids = entities.Select(PrimaryKeyExpression).ToList();

            int num = 0;

            if (ids.Any())
            {
                var primaryKey = DatabasePrimaryKey();

                var tableName = DatabaseTableName();

                foreach (var chunk in Utility.SplitList(ids, 5000))
                {
                    num += context.Database.ExecuteSqlRaw($"delete from {tableName} where {primaryKey} in ({string.Join(",", chunk)})");
                }
            }

            UpdateEntitiesAfterDelete(entities, context);

            return num;
        }

        protected virtual int Delete(TEntity entity, DbContext context)
        {
            IQueryable<TEntity> entities = new List<TEntity>() { entity }.AsQueryable();

            if (entities.Count() > 0)
            {
                GetRelatedRecordsBeforeDelete(entities);

                DeleteRelationships(entities);

                var trackers = context.ChangeTracker.Entries().ToList();

                if (trackers.Any(r => r.State != EntityState.Detached))
                {
                    context.SaveChanges();

                    ClearTrackingEntities(trackers);
                }

                InitRelationshipColumnProperties();

                ModifyRelationshipEntity(entity);

                context.Entry(entity).State = EntityState.Deleted;

                int num = context.SaveChanges();

                UpdateEntitiesAfterDelete(entities, context);

                return num;
            }

            return 0;
        }

        /// <summary>
        /// 根据某个条件删除某个对象
        /// </summary>
        /// <param name="predicate">lamda表达式查询条件</param>
        /// <returns></returns>
        public virtual void Delete(Expression<Func<TEntity, bool>> predicate)
        {
            var entities = DbSet.Where(predicate).ToList();
            DeleteRange(entities);
        }

        /// <summary>
        /// 批量删除    
        /// </summary>
        /// <param name="entityList"></param>
        public virtual void Delete(List<TEntity> entityList)
        {
            entityList.ForEach(m => { Delete(m); });
        }

        // public virtual int Delete(TEntity entity)
        // {
        //     var entityList = new List<TEntity>() { entity };
        //     GetRelatedRecordsBeforeDelete(entityList.AsQueryable());

        //     DeleteRelationships(entityList);

        //     var trackers = this.Context.ChangeTracker.Entries().ToList();

        //     if (trackers.Any(r => r.State != EntityState.Detached))
        //     {
        //         this.Context.SaveChanges();

        //         ClearTrackingEntities(trackers);
        //     }
        // }

        protected virtual void GetRelatedRecordsBeforeDelete(IQueryable<TEntity> entities)
        {

        }

        protected virtual IQueryable<TEntity> DeleteRelationships(IQueryable<TEntity> entities)
        {
            var result = entities.ToList();
            DeleteRelationships(result);
            return result.AsQueryable();
        }

        protected virtual void DeleteRelationships(IEnumerable<TEntity> entities)
        {
        }

        protected virtual IEnumerable<TEntity> AddRange(IEnumerable<TEntity> entities, DbContext context)
        {
            foreach (var entity in entities)
            {
                CheckDuplicateField(entity, context);
            }

            UpdateEntitiesBeforeCreate(entities, context);

            ClearTracker(entities.Select(PrimaryKeyExpression.Compile()).ToList());

            IEnumerable<TEntity> result = BulkAdd(entities);

            UpdateEntitiesAfterCreate(result, context);

            return result;
        }

        /// <summary>
        /// 更新某个实体对象
        /// </summary>
        /// <param name="entityToUpdate">实体对象</param>
        public virtual bool Update(TEntity entityToUpdate)
        {
            if (Context.Entry(entityToUpdate).State != EntityState.Detached)
                //      Context.Entry<TEntity>(entityToUpdate).State = EntityState;
                DbSet.Attach(entityToUpdate);
            //获取当前的所有的属性 判断属性值是不是 null 如果是null 那么就不进行更新改字段
            PropertyInfo[] properties = entityToUpdate.GetType().GetProperties();
            // Context.Entry(entityToUpdate).State = EntityState.Modified;
            foreach (PropertyInfo prop in properties)
            {
                if (prop.GetValue(entityToUpdate, null) != null)
                {
                    if (prop.GetValue(entityToUpdate, null).ToString() == "&nbsp;")
                        Context.Entry(entityToUpdate).Property(prop.Name).CurrentValue = null;
                    if (!Context.Entry(entityToUpdate).Property(prop.Name).Metadata.IsPrimaryKey()) //主键是不能进行修改的 否则无法进行更新
                    {
                        Context.Entry(entityToUpdate).Property(prop.Name).IsModified = true;
                    }
                }
            }
            return this.Context.SaveChanges() > 0;
            //Context.Entry(entityToUpdate).State = EntityState.Modified;
        }
        /// <summary>
        /// 批量编辑
        /// </summary>
        /// <param name="entitiesUpdate"></param>
        /// <returns></returns>
        public virtual bool Update(List<TEntity> entitiesUpdate)
        {
            entitiesUpdate.ForEach(m => Context.Entry<TEntity>(m).State = EntityState.Modified);
            return Context.SaveChanges() > 0;
        }





        public void ChangeDataBase(string connStr)
        {
            Context.Database.GetDbConnection().ConnectionString = connStr;
        }

        public void Save()
        {
            this.Context.SaveChanges();
        }

        public int SaveChangesCount()
        {
            return this.Context.SaveChanges();
        }

        public void Dispose()
        {
            this.Context.Dispose();
        }

        protected virtual void CheckExistedAndThrow(TEntity entity)
        {
            if (!CheckExisted(entity))
            {
                throw new Daemon.Common.Exceptions.NonexistentEntityException();
            }
        }

        protected virtual Expression<Func<TEntity, bool>> GetExpressionByAuthInfo()
        {
            return r => true;
        }

        protected Expression<Func<TEntity, bool>> GetQueryExpression<TV>(Expression<Func<TEntity, TV>> expression, TV field, LinqOperatorEnum linqOperatorEnum = LinqOperatorEnum.Equal)
        {
            ParameterExpression parameterExpression = Expression.Parameter(typeof(TEntity));

            Expression binaryExpression = ExpressionHelper.GetQueryExpression(expression.Body, parameterExpression, field, linqOperatorEnum);

            return Expression.Lambda<Func<TEntity, bool>>(binaryExpression, parameterExpression);
        }

        protected Expression<Func<TEntity, bool>> GetQueryExpression<TV>(Expression<Func<TEntity, TV>> expression, IList<TV> fields, LinqOperatorEnum linqOperatorEnum)
        {
            ParameterExpression parameterExpression = Expression.Parameter(typeof(TEntity));

            Expression binaryExpression = ExpressionHelper.GetQueryExpression(expression.Body, parameterExpression, fields, linqOperatorEnum);

            return Expression.Lambda<Func<TEntity, bool>>(binaryExpression, parameterExpression);
        }

        private void ClearTrackingEntities(IEnumerable<EntityEntry> trackingEntities)
        {
            foreach (var trackingEntity in trackingEntities)
            {
                trackingEntity.State = EntityState.Detached;
            }
        }

        private string DatabasePrimaryKey()
        {
            var entityType = Context.Model.FindEntityType("Daemon.Model." + typeof(TEntity).Name);
            var primaryKey = entityType.FindPrimaryKey();
            var primaryKeyColumn = primaryKey.Properties
                                 .Select(property => property.Name)
                                 .FirstOrDefault();
            return primaryKeyColumn;
        }

        private string DatabaseTableName()
        {
            var entityType = Context.Model.FindEntityType("Daemon.Model." + typeof(TEntity).Name);
            return entityType.GetTableName();
        }

        internal virtual IQueryable<TEntity> GetDbQuery(bool isNoTracking = true)
        {
            DbSet<TEntity> dbset = Context.Set<TEntity>();

            IQueryable<TEntity> dbquery = isNoTracking ? dbset.AsNoTracking() : dbset;

            return dbquery.Where(GetExpressionByAuthInfo());
        }

        //     private void InitRelationshipColumnProperties()
        //     {
        //         if (_relationshipColumns == null)
        //         {
        //             _relationshipColumns = ServiceLocator.GetInstance<DBContextExecutor>().GetRelationshipColumnNames<T>();
        //         }

        //         if (_columnProperties == null)
        //         {
        //             List<string> edmColumns = ServiceLocator.GetInstance<DBContextExecutor>().GetEdmColumnNames<T>();

        //             _columnProperties = typeof(T).GetProperties().Where(r => !edmColumns.Contains(r.Name) && r.SetMethod != null);
        //         }

        //         if (_relationshipProperties == null)
        //         {
        //             _relationshipProperties = _columnProperties.Where(c => _relationshipColumns.Contains(c.Name));
        //         }
        //     }
    }
}
